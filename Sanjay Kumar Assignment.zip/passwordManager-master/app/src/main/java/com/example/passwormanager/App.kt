package com.example.passwormanager

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class PasswordApp: Application() {

}